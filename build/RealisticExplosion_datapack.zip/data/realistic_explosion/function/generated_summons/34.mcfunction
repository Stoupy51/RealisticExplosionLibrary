
#> realistic_explosion:generated_summons/34
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:black_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:black_stained_glass_pane"}}
execute if data storage realistic_explosion:main {id:"minecraft:brown_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brown_stained_glass_pane"}}
execute if data storage realistic_explosion:main {id:"minecraft:cobbled_deepslate_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cobbled_deepslate_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:cracked_deepslate_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cracked_deepslate_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:green_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:green_stained_glass_pane"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_blue_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_blue_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_gray_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_gray_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:mossy_cobblestone_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mossy_cobblestone_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:mossy_stone_brick_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mossy_stone_brick_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:orange_glazed_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:orange_glazed_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_chiseled_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oxidized_chiseled_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_copper_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oxidized_copper_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_cut_copper_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oxidized_cut_copper_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_andesite_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_andesite_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_blackstone_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_blackstone_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_blackstone_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_blackstone_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:purple_glazed_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purple_glazed_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_cut_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_exposed_cut_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:weathered_copper_lantern"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:weathered_copper_lantern"}}
execute if data storage realistic_explosion:main {id:"minecraft:white_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:white_stained_glass_pane"}}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_glazed_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:yellow_glazed_terracotta"}}

