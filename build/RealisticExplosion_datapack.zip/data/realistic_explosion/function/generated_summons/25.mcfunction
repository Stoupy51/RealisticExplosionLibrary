
#> realistic_explosion:generated_summons/25
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:acacia_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:andesite_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:andesite_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:blackstone_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blackstone_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:blackstone_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blackstone_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:brain_coral_fan"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brain_coral_fan"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:chiseled_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chiseled_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:copper_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:copper_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:crying_obsidian"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:crying_obsidian"}}
execute if data storage realistic_explosion:main {id:"minecraft:cut_copper_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cut_copper_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cyan_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_button"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_leaves"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_planks"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_prismarine"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_prismarine"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_fire_coral"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_fire_coral"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_horn_coral"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_horn_coral"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_tube_coral"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_tube_coral"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_tiles"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_tiles"}}
execute if data storage realistic_explosion:main {id:"minecraft:dripstone_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dripstone_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:fletching_table"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:fletching_table"}}
execute if data storage realistic_explosion:main {id:"minecraft:gray_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gray_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:honeycomb_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:honeycomb_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_blue_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_blue_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_gray_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_gray_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:lime_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lime_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_button"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_leaves"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_planks"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:nether_gold_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:nether_gold_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:netherite_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:netherite_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:ochre_froglight"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:ochre_froglight"}}
execute if data storage realistic_explosion:main {id:"minecraft:open_eyeblossom"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:open_eyeblossom"}}
execute if data storage realistic_explosion:main {id:"minecraft:orange_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:orange_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oxidized_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_moss_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_moss_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_button"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_leaves"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_planks"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_basalt"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_basalt"}}
execute if data storage realistic_explosion:main {id:"minecraft:prismarine_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:prismarine_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:prismarine_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:prismarine_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:purple_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purple_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:short_dry_grass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:short_dry_grass"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:structure_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:structure_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:suspicious_sand"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:suspicious_sand"}}
execute if data storage realistic_explosion:main {id:"minecraft:tuff_brick_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:tuff_brick_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:tuff_brick_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:tuff_brick_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:yellow_concrete"}}

