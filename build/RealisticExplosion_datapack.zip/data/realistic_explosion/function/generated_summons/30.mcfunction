
#> realistic_explosion:generated_summons/30
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:bamboo_mosaic_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_mosaic_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:birch_pressure_plate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:birch_pressure_plate"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_concrete_powder"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_concrete_powder"}}
execute if data storage realistic_explosion:main {id:"minecraft:brown_mushroom_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brown_mushroom_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:chiseled_tuff_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chiseled_tuff_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:cracked_stone_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cracked_stone_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_hanging_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:crimson_hanging_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_concrete_powder"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cyan_concrete_powder"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_prismarine_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_prismarine_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_brain_coral_fan"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_brain_coral_fan"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_brick_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_brick_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_brick_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_brick_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_copper_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_copper_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:end_stone_brick_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:end_stone_brick_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:end_stone_brick_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:end_stone_brick_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_copper_chain"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:exposed_copper_chain"}}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_copper_chest"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:exposed_copper_chest"}}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_copper_grate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:exposed_copper_grate"}}
execute if data storage realistic_explosion:main {id:"minecraft:gray_concrete_powder"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gray_concrete_powder"}}
execute if data storage realistic_explosion:main {id:"minecraft:infested_cobblestone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:infested_cobblestone"}}
execute if data storage realistic_explosion:main {id:"minecraft:lime_concrete_powder"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lime_concrete_powder"}}
execute if data storage realistic_explosion:main {id:"minecraft:muddy_mangrove_roots"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:muddy_mangrove_roots"}}
execute if data storage realistic_explosion:main {id:"minecraft:orange_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:orange_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_copper_bars"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oxidized_copper_bars"}}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_copper_bulb"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oxidized_copper_bulb"}}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_copper_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oxidized_copper_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_concrete_powder"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_concrete_powder"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_tuff_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_tuff_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:purple_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purple_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_sandstone_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_sandstone_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:reinforced_deepslate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:reinforced_deepslate"}}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_quartz_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:smooth_quartz_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_red_sandstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:smooth_red_sandstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:stone_pressure_plate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stone_pressure_plate"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_acacia_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_acacia_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_cherry_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_cherry_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_jungle_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_jungle_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_spruce_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_spruce_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_warped_stem"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_warped_stem"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_copper_lantern"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_copper_lantern"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_exposed_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:weathered_cut_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:weathered_cut_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:yellow_stained_glass"}}

