
#> realistic_explosion:generated_summons/26
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:amethyst_cluster"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:amethyst_cluster"}}
execute if data storage realistic_explosion:main {id:"minecraft:birch_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:birch_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:black_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:black_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:brown_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brown_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:bubble_coral_fan"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bubble_coral_fan"}}
execute if data storage realistic_explosion:main {id:"minecraft:budding_amethyst"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:budding_amethyst"}}
execute if data storage realistic_explosion:main {id:"minecraft:cobblestone_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cobblestone_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:cobblestone_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cobblestone_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:crimson_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cyan_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_sapling"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_sapling"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_brain_coral"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_brain_coral"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:dried_kelp_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dried_kelp_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:enchanting_table"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:enchanting_table"}}
execute if data storage realistic_explosion:main {id:"minecraft:end_portal_frame"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:end_portal_frame"}}
execute if data storage realistic_explosion:main {id:"minecraft:end_stone_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:end_stone_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:fire_coral_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:fire_coral_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:flowering_azalea"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:flowering_azalea"}}
execute if data storage realistic_explosion:main {id:"minecraft:gray_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gray_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:green_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:green_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:horn_coral_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:horn_coral_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:lime_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lime_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:magenta_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:magenta_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:mud_brick_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mud_brick_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:oak_hanging_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oak_hanging_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_moss_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_moss_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_sapling"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_sapling"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_diorite"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_diorite"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_granite"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_granite"}}
execute if data storage realistic_explosion:main {id:"minecraft:raw_copper_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:raw_copper_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:resin_brick_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:resin_brick_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:resin_brick_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:resin_brick_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:sandstone_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:sandstone_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_sandstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:smooth_sandstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:stone_brick_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stone_brick_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:stone_brick_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stone_brick_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_oak_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_oak_log"}}
execute if data storage realistic_explosion:main {id:"minecraft:tube_coral_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:tube_coral_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_cut_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_cut_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:weathered_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:weathered_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:white_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:white_terracotta"}}

